import { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { musicAPI } from '../services/api';

export const useMusic = () => {
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [currentMusicId, setCurrentMusicId] = useState<string | null>(null);

  const playMusic = async (musicId: string) => {
    // End current session if exists
    if (currentSessionId) {
      await endCurrentSession();
    }

    // Create new session
    const newSessionId = uuidv4();
    setCurrentSessionId(newSessionId);
    setCurrentMusicId(musicId);

    // Start streaming
    await musicAPI.streamMusic(musicId, newSessionId);
  };

  const endCurrentSession = async () => {
    if (currentSessionId) {
      await musicAPI.endStream(currentSessionId);
    }
  };

  const skipToNext = async () => {
    if (currentSessionId) {
      await musicAPI.endStream(currentSessionId);
      setCurrentSessionId(null);
      setCurrentMusicId(null);
    }
  };

  const skipToPrevious = async () => {
    if (currentSessionId) {
      await musicAPI.endStream(currentSessionId);
      setCurrentSessionId(null);
      setCurrentMusicId(null);
    }
  };

  return {
    currentMusicId,
    playMusic,
    skipToNext,
    skipToPrevious,
    endCurrentSession,
  };
};