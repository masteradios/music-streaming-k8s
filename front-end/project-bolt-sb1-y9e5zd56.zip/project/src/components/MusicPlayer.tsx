import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Music } from 'lucide-react';

interface MusicPlayerProps {
  currentMusic: {
    id: string;
    musicName: string;
    artistName: string;
    musicThumbnailUrl: string;
  } | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onSkipNext: () => void;
  onSkipPrevious: () => void;
}

export const MusicPlayer: React.FC<MusicPlayerProps> = ({
  currentMusic,
  isPlaying,
  onPlayPause,
  onSkipNext,
  onSkipPrevious,
}) => {
  if (!currentMusic) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-gray-900/95 backdrop-blur-lg border-t border-gray-700/50 p-4">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-4 flex-1">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center overflow-hidden">
            {currentMusic.musicThumbnailUrl ? (
              <img 
                src={currentMusic.musicThumbnailUrl} 
                alt={currentMusic.musicName}
                className="w-full h-full object-cover"
              />
            ) : (
              <Music className="w-6 h-6 text-white" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <h4 className="text-white font-medium truncate text-sm">{currentMusic.musicName}</h4>
            <p className="text-gray-400 text-xs truncate">{currentMusic.artistName}</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <button
            onClick={onSkipPrevious}
            className="p-2 text-gray-400 hover:text-white transition-colors"
          >
            <SkipBack className="w-5 h-5" />
          </button>
          
          <button
            onClick={onPlayPause}
            className="p-3 bg-white text-black rounded-full hover:scale-105 transition-transform"
          >
            {isPlaying ? (
              <Pause className="w-5 h-5" fill="currentColor" />
            ) : (
              <Play className="w-5 h-5 ml-0.5" fill="currentColor" />
            )}
          </button>
          
          <button
            onClick={onSkipNext}
            className="p-2 text-gray-400 hover:text-white transition-colors"
          >
            <SkipForward className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1"></div>
      </div>
    </div>
  );
};